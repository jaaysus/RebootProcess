using Microsoft.AspNetCore.Mvc;
using ClosedXML.Excel;

namespace DynamicWiApi.Controllers;

[ApiController]
[Route("excel")]
public class UcsModulesController : ControllerBase
{
    [HttpPost("ucs-modules")]
    public async Task<IActionResult> GetUcsModules(IFormFile file)
    {
        if (file == null || file.Length == 0)
            return BadRequest("No file uploaded.");

        using var stream = new MemoryStream();
        await file.CopyToAsync(stream);

        using var workbook = new XLWorkbook(stream);
        var worksheet = workbook.Worksheets.First();
        var usedRows = worksheet.RowsUsed().Skip(1).ToList();

        var modulesList = new List<Dictionary<string, string>>();
        int i = 0;

        while (i < usedRows.Count)
        {
            var row = usedRows[i];
            var boldsInRow = row.CellsUsed()
                .Where(c => c.Style.Font.Bold)
                .OrderBy(c => c.Address.ColumnNumber)
                .ToList();

            if (BlanksOrConsecutiveCheck(boldsInRow, 3))
            {
                var headers = boldsInRow.Select(c => c.GetFormattedString().Trim()).ToList();
                int startCol = boldsInRow.First().Address.ColumnNumber;

                int j = i + 1;
                while (j < usedRows.Count)
                {
                    var dataRow = usedRows[j];

                    bool anyHeaderBold = false;
                    for (int k = 0; k < headers.Count; k++)
                    {
                        if (dataRow.Cell(startCol + k).Style.Font.Bold)
                        {
                            anyHeaderBold = true;
                            break;
                        }
                    }
                    if (anyHeaderBold)
                        break;

                    if (dataRow.CellsUsed().All(c => string.IsNullOrWhiteSpace(c.GetFormattedString())))
                        break;

                    var rowDict = new Dictionary<string, string>();
                    for (int k = 0; k < headers.Count; k++)
                    {
                        var valCell = dataRow.Cell(startCol + k);
                        rowDict[headers[k]] = string.IsNullOrWhiteSpace(valCell.GetFormattedString())
                            ? ""
                            : valCell.GetFormattedString().Trim();
                    }
                    modulesList.Add(rowDict);
                    j++;
                }

                i = j;
                continue;
            }

            i++;
        }

        return Ok(new { Modules_List = modulesList });
    }

    private bool BlanksOrConsecutiveCheck(List<IXLCell> bolds, int expectedCount)
    {
        if (bolds.Count != expectedCount)
            return false;

        for (int i = 1; i < bolds.Count; i++)
        {
            if (bolds[i].Address.ColumnNumber != bolds[i - 1].Address.ColumnNumber + 1)
                return false;
        }

        return true;
    }
}
