using Microsoft.AspNetCore.Mvc;
using ClosedXML.Excel;

namespace DynamicWiApi.Controllers;

[ApiController]
[Route("excel")]
public class UcsMetadataController : ControllerBase
{
    [HttpPost("ucs-metadata")]
    public async Task<IActionResult> GetUcsMetadata(IFormFile file)
    {
        if (file == null || file.Length == 0)
            return BadRequest("No file uploaded.");

        using var stream = new MemoryStream();
        await file.CopyToAsync(stream);

        using var workbook = new XLWorkbook(stream);
        var worksheet = workbook.Worksheets.First();

        // Extract metadata from row 1
        var metadata = new List<string>();
        foreach (var cell in worksheet.Row(1).CellsUsed())
        {
            var text = cell.GetFormattedString();
            if (!string.IsNullOrWhiteSpace(text))
                metadata.Add(text.Trim());
        }

        return Ok(new { Metadata = metadata });
    }
}
