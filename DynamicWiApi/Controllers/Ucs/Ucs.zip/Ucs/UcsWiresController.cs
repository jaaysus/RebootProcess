using Microsoft.AspNetCore.Mvc;
using ClosedXML.Excel;

namespace DynamicWiApi.Controllers;

[ApiController]
[Route("excel")]
public class UcsWiresController : ControllerBase
{
    [HttpPost("ucs-wires")]
    public async Task<IActionResult> GetUcsWires(
        IFormFile file,
        int? maxRows = null
    )
    {
        if (file == null || file.Length == 0)
            return BadRequest("No file uploaded.");

        using var stream = new MemoryStream();
        await file.CopyToAsync(stream);

        using var workbook = new XLWorkbook(stream);
        var worksheet = workbook.Worksheets.First();
        var usedRows = worksheet.RowsUsed().ToList();

        var wires = new Dictionary<string, Dictionary<string, object>>();
        IXLRow headerRow = null;

        // 1️⃣ Find header row (bold "Wire Nb")
        foreach (var row in usedRows)
        {
            var boldsInRow = row.CellsUsed()
                .Where(c => c.Style.Font.Bold)
                .OrderBy(c => c.Address.ColumnNumber)
                .ToList();

            if (!boldsInRow.Any())
                continue;

            if (boldsInRow.First().GetFormattedString().Trim() == "Wire Nb")
            {
                headerRow = row;
                break;
            }
        }

        if (headerRow == null)
            return BadRequest("Header row not found.");

        int currentRow = headerRow.RowNumber() + 1;

        // 2️⃣ Read data rows
        while (true)
        {
            if (maxRows.HasValue && wires.Count >= maxRows.Value)
                break;

            var dataRow = worksheet.Row(currentRow);

            var boldsInDataRow = dataRow.CellsUsed()
                .Where(c => c.Style.Font.Bold)
                .Select(c => c.GetFormattedString().Trim())
                .ToList();

            if (
                !dataRow.CellsUsed().Any() ||
                boldsInDataRow.Contains("Mult.Wire Nb") ||
                boldsInDataRow.Contains("Sleeve Nb")
            )
                break;

            var rowDict = new Dictionary<string, object>();
            string wireNb = null;

            foreach (var headerCell in headerRow.CellsUsed())
            {
                string key = headerCell.GetFormattedString().Trim();
                int colNumber = headerCell.Address.ColumnNumber;

                var value = dataRow.Cell(colNumber).GetFormattedString().Trim();
                if (string.IsNullOrWhiteSpace(value))
                    value = null;

                if (key == "Wire Nb")
                    wireNb = value;
                else
                    rowDict[key] = value;
            }

            if (!string.IsNullOrEmpty(wireNb))
                wires[wireNb] = rowDict;

            currentRow++;
        }

        return Ok(new { Wires = wires });
    }
}
