using Microsoft.AspNetCore.Mvc;
using ClosedXML.Excel;

namespace DynamicWiApi.Controllers;

[ApiController]
[Route("excel")]
public class UcsSplicesController : ControllerBase
{
    [HttpPost("ucs-splices")]
    public async Task<IActionResult> GetUcsSplices(
        IFormFile file,
        int? maxRows = null
    )
    {
        if (file == null || file.Length == 0)
            return BadRequest("No file uploaded.");

        using var stream = new MemoryStream();
        await file.CopyToAsync(stream);

        using var workbook = new XLWorkbook(stream);
        var worksheet = workbook.Worksheets.First();
        var usedRows = worksheet.RowsUsed().ToList();

        var splices = new Dictionary<string, Dictionary<string, object>>();
        IXLRow headerRow = null;

        // 1️⃣ Find header row (bold "Splice Nb")
        foreach (var row in usedRows)
        {
            var boldsInRow = row.CellsUsed()
                .Where(c => c.Style.Font.Bold)
                .OrderBy(c => c.Address.ColumnNumber)
                .ToList();

            if (!boldsInRow.Any()) continue;

            if (boldsInRow.First().GetFormattedString().Trim() == "Splice Nb")
            {
                headerRow = row;
                break;
            }
        }

        if (headerRow == null)
            return BadRequest("Header row not found.");

        int currentRow = headerRow.RowNumber() + 1;

        // 2️⃣ Read data rows
        while (true)
        {
            // Stop if reached maxRows
            if (maxRows.HasValue && splices.Count >= maxRows.Value)
                break;

            var dataRow = worksheet.Row(currentRow);

            // Stop if row is empty
            if (!dataRow.CellsUsed().Any())
                break;

            var rowDict = new Dictionary<string, object>();
            string spliceNb = null;

            foreach (var headerCell in headerRow.CellsUsed())
            {
                string key = headerCell.GetFormattedString().Trim();
                int colNumber = headerCell.Address.ColumnNumber;

                var value = dataRow.Cell(colNumber).GetFormattedString().Trim();
                if (string.IsNullOrWhiteSpace(value))
                    value = null;

                if (key == "Splice Nb")
                    spliceNb = value;
                else if (key == "Extra Component PN" && value != null)
                    rowDict[key] = value.Split(',')
                                         .Select(s => s.Trim())
                                         .Where(s => !string.IsNullOrEmpty(s))
                                         .ToArray();
                else
                    rowDict[key] = value;
            }

            if (!string.IsNullOrEmpty(spliceNb))
                splices[spliceNb] = rowDict;

            currentRow++;
        }

        return Ok(new { Splices = splices });
    }
}
