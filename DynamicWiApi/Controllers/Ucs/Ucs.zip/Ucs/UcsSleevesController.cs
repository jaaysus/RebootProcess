using Microsoft.AspNetCore.Mvc;
using ClosedXML.Excel;

namespace DynamicWiApi.Controllers;

[ApiController]
[Route("excel")]
public class UcsSleevesController : ControllerBase
{
    [HttpPost("ucs-sleeves")]
    public async Task<IActionResult> GetUcsSleeves(IFormFile file)
    {
        if (file == null || file.Length == 0)
            return BadRequest("No file uploaded.");

        using var stream = new MemoryStream();
        await file.CopyToAsync(stream);

        using var workbook = new XLWorkbook(stream);
        var worksheet = workbook.Worksheets.First();
        var usedRows = worksheet.RowsUsed().ToList();

        var sleeves = new Dictionary<string, Dictionary<string, object>>();
        IXLRow headerRow = null;

        // 1️⃣ Find header row (bold cells with "Sleeve Nb")
        foreach (var row in usedRows)
        {
            var boldsInRow = row.CellsUsed()
                .Where(c => c.Style.Font.Bold)
                .OrderBy(c => c.Address.ColumnNumber)
                .ToList();

            if (!boldsInRow.Any()) continue;

            if (boldsInRow.First().GetFormattedString().Trim() == "Sleeve Nb")
            {
                headerRow = row;
                break; // stop after first header row
            }
        }

        if (headerRow == null)
            return BadRequest("Header row not found.");

        int headerRowNumber = headerRow.RowNumber();

        // 2️⃣ Loop through all rows after header until "Splice Nb" is bold
        int currentRow = headerRowNumber + 1;
        while (true)
        {
            var dataRow = worksheet.Row(currentRow);

            // Stop if row contains bold "Splice Nb"
            var boldsInDataRow = dataRow.CellsUsed()
                .Where(c => c.Style.Font.Bold)
                .Select(c => c.GetFormattedString().Trim())
                .ToList();

            if (boldsInDataRow.Contains("Splice Nb") || !dataRow.CellsUsed().Any())
                break;

            var rowDict = new Dictionary<string, object>();
            string sleeveNb = null;

            foreach (var cell in headerRow.CellsUsed())
            {
                string key = cell.GetFormattedString().Trim();
                int colNumber = cell.Address.ColumnNumber;
                var cellValue = dataRow.Cell(colNumber).GetFormattedString().Trim();
                if (string.IsNullOrEmpty(cellValue)) cellValue = null;

                if (key == "Sleeve Nb")
                    sleeveNb = cellValue; // main key
                else
                    rowDict[key] = cellValue;
            }

            if (!string.IsNullOrEmpty(sleeveNb))
                sleeves[sleeveNb] = rowDict;

            currentRow++;
        }

        return Ok(new { Sleeves = sleeves });
    }
}
