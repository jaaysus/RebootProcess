using Microsoft.AspNetCore.Mvc;
using ClosedXML.Excel;

namespace DynamicWiApi.Controllers;

[ApiController]
[Route("excel")]
public class UcsFamilyController : ControllerBase
{
    [HttpPost("ucs-family")]
    public async Task<IActionResult> GetUcsFamily(IFormFile file)
    {
        if (file == null || file.Length == 0)
            return BadRequest("No file uploaded.");

        using var stream = new MemoryStream();
        await file.CopyToAsync(stream);

        using var workbook = new XLWorkbook(stream);
        var worksheet = workbook.Worksheets.First();

        // Skip header row
        var rows = worksheet.RowsUsed().Skip(1).ToList();

        // One family per upload
        var family = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);

        int i = 0;
        while (i < rows.Count)
        {
            var row = rows[i];

            var boldCells = row.CellsUsed()
                .Where(c => c.Style.Font.Bold)
                .OrderBy(c => c.Address.ColumnNumber)
                .ToList();

            // Stop when next section starts (2+ bold cells)
            if (boldCells.Count >= 2)
                break;

            if (boldCells.Count == 1)
            {
                var keyCell = boldCells[0];
                var key = keyCell.GetFormattedString().Trim();

                int startCol = keyCell.Address.ColumnNumber + 1;
                int lastCol = row.LastCellUsed()?.Address.ColumnNumber ?? startCol;

                var values = new List<string>();

                for (int col = startCol; col <= lastCol; col++)
                {
                    var cell = row.Cell(col);

                    if (cell.Style.Font.Bold)
                        break;

                    var text = cell.GetFormattedString().Trim();
                    if (!string.IsNullOrEmpty(text))
                        values.Add(text);
                }

                family[key] = values.Count switch
                {
                    0 => "",
                    1 => values[0],
                    _ => values
                };
            }

            i++;
        }

        // IMPORTANT: return as ARRAY so frontend renders 1 proper table
        return Ok(new[] { family });
    }
}
