using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using DynamicWiApi.Data;
using DynamicWiApi.Models;
using System.Reflection;

namespace DynamicWi.Controllers;

[ApiController]
[Route("api/process-excel")]
[Authorize]
public class ProcessController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly ILogger<ProcessController> _logger;

    public ProcessController(AppDbContext db, ILogger<ProcessController> logger)
    {
        _db = db;
        _logger = logger;
    }

    /// <summary>
    /// Get all process Excel data records
    /// </summary>
    [HttpGet]
    public IActionResult GetProcessExcelData()
    {
        try
        {
            var data = _db.ProcessExcelData.ToList();
            return Ok(new { success = true, data });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving process Excel data");
            return BadRequest(new { success = false, message = ex.Message });
        }
    }

    /// <summary>
    /// Get process Excel data by ID
    /// </summary>
    [HttpGet("{id}")]
    public IActionResult GetProcessExcelDataById(Guid id)
    {
        try
        {
            var data = _db.ProcessExcelData.FirstOrDefault(p => p.Id == id);
            if (data == null)
                return NotFound(new { success = false, message = "Process Excel data not found" });

            return Ok(new { success = true, data });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving process Excel data by ID");
            return BadRequest(new { success = false, message = ex.Message });
        }
    }

    /// <summary>
    /// Get process data by station
    /// </summary>
    [HttpGet("station/{station}")]
    public IActionResult GetProcessExcelDataByStation(string station)
    {
        try
        {
            var data = _db.ProcessExcelData
                .Where(p => p.Station == station)
                .ToList();

            return Ok(new { success = true, count = data.Count, data });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving process Excel data by station");
            return BadRequest(new { success = false, message = ex.Message });
        }
    }

    /// <summary>
    /// Get process data by component
    /// </summary>
    [HttpGet("component/{component}")]
    public IActionResult GetProcessExcelDataByComponent(string component)
    {
        try
        {
            var data = _db.ProcessExcelData
                .Where(p => p.Component == component)
                .ToList();

            return Ok(new { success = true, count = data.Count, data });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving process Excel data by component");
            return BadRequest(new { success = false, message = ex.Message });
        }
    }

    /// <summary>
    /// Create new process Excel data record
    /// </summary>
    [HttpPost]
    [Authorize(Roles = "Admin,ProcessTechnician")]
    public IActionResult CreateProcessExcelData([FromBody] ProcessExcelData processData)
    {
        try
        {
            var userIdClaim = User.FindFirst("UserId")?.Value;
            var currentUser = _db.Users.FirstOrDefault(u => u.Id == Guid.Parse(userIdClaim ?? ""));

            if (string.IsNullOrWhiteSpace(processData.Description))
                return BadRequest(new { success = false, message = "Description is required" });

            processData.Id = Guid.NewGuid();
            processData.CreatedAt = DateTime.UtcNow;
            processData.CreatedBy = currentUser?.Badge ?? "Unknown";

            _db.ProcessExcelData.Add(processData);
            _db.AuditLogs.Add(new AuditLog
            {
                Action = "Create",
                Entity = "ProcessExcelData",
                UserBadge = currentUser?.Badge ?? "Unknown",
                Details = $"ID: {processData.Id} | Component: {processData.Component}, Station: {processData.Station}"
            });

            _db.SaveChanges();
            return Ok(new { success = true, message = "Process Excel data created successfully", data = processData });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating process Excel data");
            return BadRequest(new { success = false, message = ex.Message });
        }
    }

    /// <summary>
    /// Update process Excel data record
    /// </summary>
    [HttpPut("{id}")]
    [Authorize(Roles = "Admin,ProcessTechnician")]
    public IActionResult UpdateProcessExcelData(Guid id, [FromBody] ProcessExcelData updatedData)
    {
        try
        {
            var existingData = _db.ProcessExcelData.FirstOrDefault(p => p.Id == id);
            if (existingData == null)
                return NotFound(new { success = false, message = "Process Excel data not found" });

            var userIdClaim = User.FindFirst("UserId")?.Value;
            var currentUser = _db.Users.FirstOrDefault(u => u.Id == Guid.Parse(userIdClaim ?? ""));

            // Update properties
            existingData.Description = updatedData.Description ?? existingData.Description;
            existingData.DescriptionExtra = updatedData.DescriptionExtra ?? existingData.DescriptionExtra;
            existingData.SortieComponent = updatedData.SortieComponent ?? existingData.SortieComponent;
            existingData.Component = updatedData.Component ?? existingData.Component;
            existingData.AddedItems = updatedData.AddedItems ?? existingData.AddedItems;
            existingData.Core = updatedData.Core ?? existingData.Core;
            existingData.SpLoc = updatedData.SpLoc ?? existingData.SpLoc;
            existingData.Csa = updatedData.Csa ?? existingData.Csa;
            existingData.Length = updatedData.Length;
            existingData.WireName = updatedData.WireName ?? existingData.WireName;
            existingData.C1 = updatedData.C1 ?? existingData.C1;
            existingData.C2 = updatedData.C2 ?? existingData.C2;
            existingData.C3 = updatedData.C3 ?? existingData.C3;
            existingData.Node1 = updatedData.Node1 ?? existingData.Node1;
            existingData.Cav1 = updatedData.Cav1 ?? existingData.Cav1;
            existingData.Node2 = updatedData.Node2 ?? existingData.Node2;
            existingData.Cav2 = updatedData.Cav2 ?? existingData.Cav2;
            existingData.Module = updatedData.Module ?? existingData.Module;
            existingData.Station = updatedData.Station ?? existingData.Station;
            existingData.UpdatedAt = DateTime.UtcNow;
            existingData.UpdatedBy = currentUser?.Badge ?? "Unknown";

            _db.AuditLogs.Add(new AuditLog
            {
                Action = "Update",
                Entity = "ProcessExcelData",
                UserBadge = currentUser?.Badge ?? "Unknown",
                Details = $"ID: {id} | Component: {existingData.Component}, Station: {existingData.Station}"
            });

            _db.SaveChanges();
            return Ok(new { success = true, message = "Process Excel data updated successfully", data = existingData });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating process Excel data");
            return BadRequest(new { success = false, message = ex.Message });
        }
    }

    /// <summary>
    /// Delete process Excel data record
    /// </summary>
    [HttpDelete("{id}")]
    [Authorize(Roles = "Admin")]
    public IActionResult DeleteProcessExcelData(Guid id)
    {
        try
        {
            var data = _db.ProcessExcelData.FirstOrDefault(p => p.Id == id);
            if (data == null)
                return NotFound(new { success = false, message = "Process Excel data not found" });

            var userIdClaim = User.FindFirst("UserId")?.Value;
            var currentUser = _db.Users.FirstOrDefault(u => u.Id == Guid.Parse(userIdClaim ?? ""));

            _db.ProcessExcelData.Remove(data);
            _db.AuditLogs.Add(new AuditLog
            {
                Action = "Delete",
                Entity = "ProcessExcelData",
                UserBadge = currentUser?.Badge ?? "Unknown",
                Details = $"ID: {id} | Component: {data.Component}, Station: {data.Station}"
            });

            _db.SaveChanges();
            return Ok(new { success = true, message = "Process Excel data deleted successfully" });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error deleting process Excel data");
            return BadRequest(new { success = false, message = ex.Message });
        }
    }

    /// <summary>
    /// Bulk import process Excel data
    /// </summary>
    [HttpPost("bulk-import")]
    [Authorize(Roles = "Admin")]
    public IActionResult BulkImportProcessExcelData([FromBody] List<ProcessExcelData> processDataList)
    {
        try
        {
            var userIdClaim = User.FindFirst("UserId")?.Value;
            var currentUser = _db.Users.FirstOrDefault(u => u.Id == Guid.Parse(userIdClaim ?? ""));

            if (processDataList == null || processDataList.Count == 0)
                return BadRequest(new { success = false, message = "No data provided for import" });

            foreach (var item in processDataList)
            {
                item.Id = Guid.NewGuid();
                item.CreatedAt = DateTime.UtcNow;
                item.CreatedBy = currentUser?.Badge ?? "Unknown";
                _db.ProcessExcelData.Add(item);
            }

            _db.AuditLogs.Add(new AuditLog
            {
                Action = "BulkImport",
                Entity = "ProcessExcelData",
                UserBadge = currentUser?.Badge ?? "Unknown",
                Details = $"Bulk import of {processDataList.Count} process Excel data records"
            });

            _db.SaveChanges();
            return Ok(new { success = true, message = $"Successfully imported {processDataList.Count} records", importedCount = processDataList.Count });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error during bulk import of process Excel data");
            return BadRequest(new { success = false, message = ex.Message });
        }
    }

    /// <summary>
    /// Get process data summary by station
    /// </summary>
    [HttpGet("summary/by-station")]
    public IActionResult GetSummaryByStation()
    {
        try
        {
            var summary = _db.ProcessExcelData
                .GroupBy(p => p.Station)
                .Select(g => new
                {
                    station = g.Key,
                    count = g.Count(),
                    components = g.Select(p => p.Component).Distinct().ToList()
                })
                .ToList();

            return Ok(new { success = true, data = summary });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving summary by station");
            return BadRequest(new { success = false, message = ex.Message });
        }
    }

    /// <summary>
    /// Get process data summary by component
    /// </summary>
    [HttpGet("summary/by-component")]
    public IActionResult GetSummaryByComponent()
    {
        try
        {
            var summary = _db.ProcessExcelData
                .GroupBy(p => p.Component)
                .Select(g => new
                {
                    component = g.Key,
                    count = g.Count(),
                    stations = g.Select(p => p.Station).Distinct().ToList()
                })
                .ToList();

            return Ok(new { success = true, data = summary });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving summary by component");
            return BadRequest(new { success = false, message = ex.Message });
        }
    }
}
